package com.gyp.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootFreemarkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
